SELECT * FROM horario;

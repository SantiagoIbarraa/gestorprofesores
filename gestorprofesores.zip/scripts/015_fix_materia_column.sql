-- Renombrar la columna cargahoraria a carga_horaria en la tabla materia
ALTER TABLE materia RENAME COLUMN cargahoraria TO carga_horaria;
